import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {BlogComponent} from "./blog/blog.component";
import {ContactComponent} from "./contact/contact.component";
import {AboutComponent} from "./about/about.component";
import {PriceComponent} from "./price/price.component";
import {TeamComponent} from "./team/team.component";
import {WorksComponent} from "./works/works.component";
import {NewsComponent} from "./news/news.component";
import {IndexComponent} from "./index/index.component";

const routes: Routes = [
  {path: '', component: IndexComponent},
  {path:'blog', component: BlogComponent},
  {path:'contact', component:ContactComponent},
  {path:'about', component:AboutComponent},
  {path:'price',component:PriceComponent},
  {path:'team', component:TeamComponent},
  {path:'work', component:WorksComponent},
  {path:'news', component:NewsComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
