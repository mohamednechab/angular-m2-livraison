import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-skills',
  templateUrl: './skills.component.html',
  styleUrls: ['./skills.component.css']
})
export class SkillsComponent implements OnInit {
  skills = ["Web Design", "Html", "JQuery", "CSS3"];
  values = ["86", "93", "88", "95"];
  delays = ["300ms","500ms","800ms","110ms"];
  constructor() { }

  ngOnInit(): void {
  }

}
