export class Profile {

  fname: string;
  lname: string;
  image: string;
  role: string;
  fbLink: string;
  twLink: string;
  mail: string;

  constructor(fname: string, lname: string, image: string, role: string, fbLink: string, twLink: string, mail: string) {
    this.fname = fname;
    this.lname = lname;
    this.image = image;
    this.role = role;
    this.fbLink = fbLink;
    this.twLink = twLink;
    this.mail = mail;
  }
}
