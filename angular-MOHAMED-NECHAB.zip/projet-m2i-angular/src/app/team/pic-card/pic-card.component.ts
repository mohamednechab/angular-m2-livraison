import {Component, Input, OnInit} from '@angular/core';
import {Profile} from "../model/profile.model";

@Component({
  selector: 'app-pic-card',
  templateUrl: './pic-card.component.html',
  styleUrls: ['./pic-card.component.css']
})
export class PicCardComponent implements OnInit {
  @Input()
  profile:Profile = new Profile("","","","","","","");


  constructor() {
  }

  ngOnInit(): void {
  }
}
