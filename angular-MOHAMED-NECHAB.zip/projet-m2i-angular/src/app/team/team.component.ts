import {Component, OnInit} from '@angular/core';
import {Profile} from "./model/profile.model";

@Component({
  selector: 'app-team',
  templateUrl: './team.component.html',
  styleUrls: ['./team.component.css']
})
export class TeamComponent implements OnInit {
  profile1: Profile = new Profile("Jane", "Doe", "assets/images/team/member-1.jpg", "CEO", "https://fb.com/doe", "#", "#");
  profile2: Profile = new Profile("Mark", "Wood", "assets/images/team/member-2.jpg", "Creative Director", "#", "#", "#");
  profile3: Profile = new Profile("Ken", "Smith", "assets/images/team/member-3.jpg", "Sales Manager", "#", "#", "#");
  profile4: Profile = new Profile("Jamie", "Duff", "assets/images/team/member-4.jpg", "Senior Developer", "#", "#", "#");
  profiles: Array<Profile> | undefined;

  constructor() {
    this.profiles = [this.profile1, this.profile2, this.profile3, this.profile4]

  }

  ngOnInit(): void {
  }

}
