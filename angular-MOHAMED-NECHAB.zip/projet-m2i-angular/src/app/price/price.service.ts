import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PriceService {
  allPrice: any = [];

  getPrices() {
    return this.allPrice = PriceDetails.slice(0);
  }
}
const PriceDetails = [
  {"title":"Starter", "price":"$19/m", "users":"Up to 3 Users", "items":"Max 30 items","icon":"fa fa-paper-plane" },
  {"title":"Medium", "price":"$69/m", "users":"Up to 5 Users", "items":"Max 50 items","icon":"fa fa-rocket" },
  {"title":"Business", "price":"$99/m", "users":"Up to 30 Users", "items":"Max 300 items","icon":"fa fa-line-chart" },
  {"title":"Professional", "price":"$120/m", "users":"Up to 100 Users", "items":"Max 500 items","icon":"fa fa-road" }
]
