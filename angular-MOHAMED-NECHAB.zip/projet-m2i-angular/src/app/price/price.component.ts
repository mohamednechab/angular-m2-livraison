import { Component, OnInit } from '@angular/core';
import {ImageService} from "../works/image.service";
import {PriceService} from "./price.service";

@Component({
  selector: 'app-price',
  templateUrl: './price.component.html',
  styleUrls: ['./price.component.css']
})
export class PriceComponent implements OnInit {
  allPrices:any[] = [];
  constructor(private priceService: PriceService) {
    this.allPrices = this.priceService.getPrices();
  }

  ngOnInit(): void {
  }

}
