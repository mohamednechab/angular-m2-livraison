import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partner',
  templateUrl: './partner.component.html',
  styleUrls: ['./partner.component.css']
})
export class PartnerComponent implements OnInit {
  numbers: any;

  constructor() {
    this.numbers = Array(8).fill(0).map((x,i)=>i);
  }

  ngOnInit(): void {
  }

}
