import {Injectable} from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ImageService {
  allImages: any = [];

  getImages() {
    return this.allImages = Imagesdelatils.slice(0);
  }
}

const Imagesdelatils = [
  {"id": 1, "icon": "fa fa-image", "text": "text1", "category": "image", "url": "assets/images/works/i1.jpg"},
  {"id": 2, "icon": "fa fa-image", "text": "text2", "category": "image", "url": "assets/images/works/i2.jpg"},
  {"id": 3, "icon": "fa fa-image", "text": "text3", "category": "image", "url": "assets/images/works/i3.jpg"},
  {"id": 4, "icon": "fa fa-image", "text": "text4", "category": "image", "url": "assets/images/works/i4.jpg"},
  {"id": 5, "icon": "fa fa-video-camera", "text": "text5", "category": "video", "url": "assets/images/works/v1.jpg"},
  {"id": 6, "icon": "fa fa-video-camera", "text": "text6", "category": "video", "url": "assets/images/works/v2.jpg"},
  {"id": 7, "icon": "fa fa-video-camera", "text": "text7", "category": "video", "url": "assets/images/works/v3.jpg"},
  {"id": 8, "icon": "fa fa-video-camera", "text": "text8", "category": "video", "url": "assets/images/works/v4.jpg"},
  {"id": 9, "icon": "fa fa-graduation-cap", "text": "text9", "category": "project", "url": "assets/images/works/p1.jpg"},
  {"id": 10, "icon": "fa fa-graduation-cap", "text": "text10", "category": "project", "url": "assets/images/works/p2.jpg"},
  {"id": 11, "icon": "fa fa-graduation-cap", "text": "text11", "category": "project", "url": "assets/images/works/p3.jpg"},
  {"id": 12, "icon": "fa fa-graduation-cap", "text": "text12", "category": "project", "url": "assets/images/works/p4.jpg"},


]

