import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AboutComponent } from './about/about.component';
import { FooterComponent } from './footer/footer.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { BlogComponent } from './blog/blog.component';
import { TeamComponent } from './team/team.component';
import { WorksComponent } from './works/works.component';
import { PriceComponent } from './price/price.component';
import { NewsComponent } from './news/news.component';
import { ContactComponent } from './contact/contact.component';
import { IndexComponent } from './index/index.component';
import {NgbCarouselModule} from "@ng-bootstrap/ng-bootstrap";
import { PicCardComponent } from './team/pic-card/pic-card.component';
import { SkillsComponent } from './skills/skills.component';
import { RouterModule } from '@angular/router';
import {ImageGalleryComponent} from "./works/image-gallery/image-gallery.component";
import {FilterimagesPipe} from "./works/filterimages.pipe";
import {PartnerComponent} from "./works/partner/partner.component";

@NgModule({
  declarations: [
    AppComponent,
    AboutComponent,
    FooterComponent,
    NavBarComponent,
    BlogComponent,
    TeamComponent,
    WorksComponent,
    PriceComponent,
    NewsComponent,
    ContactComponent,
    IndexComponent,
    PicCardComponent,
    SkillsComponent,
    FilterimagesPipe,
    PartnerComponent,
    ImageGalleryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbCarouselModule,
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
