import {Component, OnInit, Output} from '@angular/core';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
  images = [1, 2, 3].map((n) => `../../assets/images/slider/bg-${n}.jpg`);
  title = ["CREATIVE TEAM", "MODERN DESIGN", "RESPONSIVE THEME"];
  description = ["Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.",
    "Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.",
    "Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit."]
  funFacts = ["612", "432", "957", "8912"];
  funDesc = ["CUPS OF COFFEE", "HAPPY CLIENTS", "SONG LISTENED", "ROWS OF CODE"];

  constructor() {
  }

  @Output() onHide = new EventEmitter<boolean>();
  setHide(){
    this.onHide.emit(true);
  }
  ngOnInit(): void {

  }

}
